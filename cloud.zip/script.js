const uploadForm = document.getElementById('upload-form');
const fileInput = document.getElementById('file-input');
const uploadBtn = document.getElementById('upload-btn');
const downloadLink = document.getElementById('download-link');

uploadBtn.addEventListener('click', (e) => {
  e.preventDefault();
  const file = fileInput.files[0];
  const formData = new FormData();
  formData.append('file', file);

  fetch('/upload', {
    method: 'POST',
    body: formData
  })
  .then((response) => response.json())
  .then((data) => {
    console.log(data);
    const downloadUrl = `/download/${data.filename}`;
    const link = document.createElement('a');
    link.href = downloadUrl;
    link.download = data.filename;
    link.innerHTML = `Download ${data.filename}`;
    downloadLink.appendChild(link);
  })
  .catch((error) => console.error(error));
});
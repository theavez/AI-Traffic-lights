const express = require('express');
const app = express();
const multer = require('multer');
const path = require('path');

const upload = multer({ dest: './uploads/' });

app.use(express.static('public'));

app.post('/upload', upload.single('file'), (req, res) => {
  const file = req.file;
  const filename = file.originalname;
  const filePath = path.join(__dirname, 'uploads', filename);
  res.json({ filename });
});

app.get('/download/:filename', (req, res) => {
  const filename = req.params.filename;
  const filePath = path.join(__dirname, 'uploads', filename);
  res.download(filePath, filename);
});

app.listen(3000, () => {
  console.log('Server started on port 3000');
});
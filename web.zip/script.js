const paragraph = document.getElementById('add');
const copyButton = document.getElementById('copy-btn');

copyButton.addEventListener('click', async () => {
  try {

    const text = paragraph.textContent;
    const clipboardItem = new ClipboardItem({ 'text/plain': new Blob([text], { type: 'text/plain' }) });
    await navigator.clipboard.write([clipboardItem]);
  } catch (error) {
    console.error('Error copying text to clipboard:', error);
  }
});

// Countdown timer JavaScript code
const countdownContainer = document.querySelector('.countdown-container');
const countdownElement = document.querySelector('#countdown');

// Set the countdown date and time
const countdownDate = new Date("2024-08-25T00:00:00+05:30");

// Update the countdown every second
setInterval(() => {
  const now = new Date();
  const timeRemaining = countdownDate - now;

  const days = Math.floor(timeRemaining / (1000 * 60 * 60 * 24));
  const hours = Math.floor((timeRemaining % (1000 * 60 * 60 * 24)) / (1000 * 60 * 60));
  const minutes = Math.floor((timeRemaining % (1000 * 60 * 60)) / (1000 * 60));
  const seconds = Math.floor((timeRemaining % (1000 * 60)) / 1000);

  countdownElement.innerHTML = `
    <span>${days} days</span>
    <span>${hours} hours</span>
    <span>${minutes} minutes</span>
    <span>${seconds} seconds</span>
  `;
}, 1000);

const button = document.querySelector('#copy-btn');
const div = document.querySelector('.intro');

if (button.parentNode === div) {
  console.log('The button is inside the div');
  
  button.hide()
}